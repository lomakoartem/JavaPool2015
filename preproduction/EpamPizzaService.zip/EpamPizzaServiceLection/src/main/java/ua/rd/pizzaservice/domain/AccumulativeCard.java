package ua.rd.pizzaservice.domain;

/**
 *
 * @author andrii
 */
public class AccumulativeCard {
    private Customer customer;
}
