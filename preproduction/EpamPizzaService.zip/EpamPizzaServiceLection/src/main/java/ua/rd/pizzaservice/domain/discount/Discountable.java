package ua.rd.pizzaservice.domain.discount;

/**
 *
 * @author andrii
 */
public interface Discountable {
    double calculateDiscount();
}
