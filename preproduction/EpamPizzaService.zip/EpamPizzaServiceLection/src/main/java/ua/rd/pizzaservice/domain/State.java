package ua.rd.pizzaservice.domain;

/**
 *
 * @author andrii
 */
public class State {
    public final String state;

    public State() {
        this("");
    }
    
    public State(String state) {
        this.state = state;
    }    
}
